# CS231
CS231 at Kettering University with Dr. Vineyard. 
DO NOT USE FOR PLAGIRISM. 
I'm releasing this code as a public testament of my learning progress, and to help others at the university.
