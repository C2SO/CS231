-- Written by Joseph Maples
mathFunc x y = 5 * x + 7 * y
