-- Written by Joseph Maples
main = do
    putStrLn "My name is Joseph Maples"
